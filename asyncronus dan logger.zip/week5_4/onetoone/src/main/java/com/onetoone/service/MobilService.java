package com.onetoone.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.onetoone.dto.MobilDto;
import com.onetoone.dto.ResponseMobilDto;
import com.onetoone.entity.Mobil;
import org.springframework.http.ResponseEntity;
import org.springframework.web.multipart.MultipartFile;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.List;

public interface MobilService {
    public void getTodo() throws JsonProcessingException;

    public MobilDto create(MobilDto mobilDto);

    public MobilDto updateBrand(MobilDto mobilDto);

    public MobilDto updateDetail(MobilDto mobilDto);

    public MobilDto updateDetail2(MobilDto mobilDto);

    public ResponseMobilDto getAll(int pageNo, int pageSize);

    public MobilDto deleteById(Integer id);

    public MobilDto getById(Integer id) throws JsonProcessingException;

    public MobilDto uploadImage(Integer id, MultipartFile image);

    public MobilDto createByFile(MultipartFile image, MultipartFile file);

    public MobilDto createByForm(MultipartFile image, String brand, String color, String price);

    public String createByFiles(MultipartFile[] files);
}
