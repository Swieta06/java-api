package com.onetoone.repository;

import com.onetoone.entity.Mobil;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface MobilRepository extends JpaRepository<Mobil, Long> {
    // jpql: update ... set ... where ...
    @Modifying
    @Query("UPDATE Mobil m SET m.brand = :brand WHERE m.id = :id")
    public void updateBrand(@Param("brand") String brand, @Param("id") Long id);

    // update ... inner join ... set ... where ...
    @Modifying
    @Query(value = "UPDATE mobil m" +
            " INNER JOIN mobil_detail md ON m.mobil_detail_id=md.id" +
            " SET m.brand = :brand, md.color = :color, md.year = :year, md.name = :name, md.price = :price" +
            " WHERE m.id = :id", nativeQuery = true)
    public void updateDetail(@Param("brand") String brand, @Param("color") String color,
                             @Param("year") Integer year, @Param("price") Double price,
                             @Param("name") String name, @Param("id") Long id);
}
