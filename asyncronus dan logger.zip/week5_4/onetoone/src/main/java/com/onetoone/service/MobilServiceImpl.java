package com.onetoone.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.google.gson.Gson;
import com.onetoone.dto.MobilDetailDto;
import com.onetoone.dto.MobilDto;
import com.onetoone.dto.ResponseMobilDto;
import com.onetoone.entity.Mobil;
import com.onetoone.entity.MobilDetail;
import com.onetoone.dto.PlaceHolder;
import com.onetoone.dto.Student;
import com.onetoone.repository.MobilDetailRepository;
import com.onetoone.repository.MobilRepository;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import javax.transaction.Transactional;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.stream.Collectors;

@Service
public class MobilServiceImpl implements MobilService {

    @Autowired
    private MobilRepository mobilRepository;

    @Autowired
    private MobilDetailRepository mobilDetailRepository;

    @Override
    public void getTodo() throws JsonProcessingException {

        RestTemplate restTemplate = new RestTemplate();
        List<PlaceHolder> response = restTemplate.getForObject("https://jsonplaceholder.typicode.com/posts",
                List.class);

        PlaceHolder placeHolder = restTemplate.getForObject("https://jsonplaceholder.typicode.com/posts/{id}",
                PlaceHolder.class, 1);
        System.out.println("placeHolder.getUserId() = " + placeHolder.getUserId());
        System.out.println("placeHolder.getId() = " + placeHolder.getId());
        System.out.println("placeHolder.getTitle() = " + placeHolder.getTitle());
        System.out.println("placeHolder.getBody() = " + placeHolder.getBody());

        //
        String studentJsonString = "{" +
                "\"id\": 8," +
                "\"name\": \"Gajahmada\"," +
                "\"gpa\": 4.0," +
                "\"email\": null," +
                "\"passengers\": [{\"name\": \"jensen\",\"age\": 30},{\"name\": \"Jennifer\",\"age\": 35},{\"name\": \"Kelvin\",\"age\": 25}]" +
                "}";

        ObjectMapper objectMapper = new ObjectMapper();

        // JsonNode
        JsonNode jsonNode = objectMapper.readTree(studentJsonString);

        int id = jsonNode.get("id").asInt();
        String name = jsonNode.get("name").asText();
        double gpa = jsonNode.get("gpa").asDouble();
        String email = jsonNode.get("email").asText();
        JsonNode passengerList = jsonNode.get("passengers");

        System.out.println("id: " + id);
        System.out.println("name: " + name);
        System.out.println("gpa: " + gpa);
        System.out.println("email: " + email);

        if (passengerList.isArray()) {
            for (JsonNode passenger : passengerList) {
                System.out.println("  name: " + passenger.get("name"));
                System.out.println("  age: " +passenger.get("age"));
            }
        }

        // Gson
        Gson gson = new Gson();
        Student student = gson.fromJson(studentJsonString, Student.class);
        System.out.println("gson name: " + student.getName());
        System.out.println("gson gpa: " + student.getGpa());
        System.out.println("gson passenger(0): " + student.getPassengers().get(0));
        System.out.println("gson passenger(1): " + student.getPassengers().get(1));
        System.out.println("gson passenger(2): " + student.getPassengers().get(2));
    }

    @Override
    public MobilDto create(MobilDto mobilDto) {
        Mobil mobil = convertMobilDtoToMobil(mobilDto);

        Mobil mobilCreated = mobilRepository.save(mobil);

        MobilDto mobilDtoCreated = convertMobilToMobilDto(mobilCreated);

        return mobilDtoCreated;
    }

    @Transactional
    public MobilDto updateBrand(MobilDto mobilDto) {
        mobilRepository.updateBrand(mobilDto.getBrand(), mobilDto.getId());

        return mobilDto;
    }

    @Override
    @Transactional
    public MobilDto updateDetail(MobilDto mobilDto) {
        mobilRepository.updateDetail(mobilDto.getBrand(), mobilDto.getMobilDetailDto().getColor(),
                mobilDto.getMobilDetailDto().getYear(), mobilDto.getMobilDetailDto().getPrice(),
                mobilDto.getMobilDetailDto().getName(), mobilDto.getId());

        return mobilDto;
    }

    @Override
    public MobilDto updateDetail2(MobilDto mobilDto) {
        Optional<Mobil> mobilOptional = mobilRepository.findById(mobilDto.getId());

        if (mobilOptional.isPresent()) {
            Mobil mobil = mobilOptional.get();
            mobil.setBrand(mobilDto.getBrand());
                MobilDetail mobilDetail = mobil.getMobilDetail();
                mobilDetail.setYear(mobilDto.getMobilDetailDto().getYear());
                mobilDetail.setName(mobilDto.getMobilDetailDto().getName());
                mobilDetail.setPrice(mobilDto.getMobilDetailDto().getPrice());
                mobilDetail.setSpec(mobilDto.getMobilDetailDto().getSpec());
            mobil.setMobilDetail(mobilDetail);
            mobilRepository.save(mobil);

            return mobilDto;
        } else {
            return null;
        }

    }

    @Override
    public ResponseMobilDto getAll(int pageNo, int pageSize) {
        ResponseMobilDto responseMobilDto = new ResponseMobilDto();

        Pageable pageable = PageRequest.of(pageNo - 1, pageSize);

        Page<Mobil> mobilList = mobilRepository.findAll(pageable);
        List<MobilDto> mobilDtoList = new ArrayList<>();

        for (Mobil mobil : mobilList) {
            MobilDto mobilDto = convertMobilToMobilDto(mobil);
            mobilDtoList.add(mobilDto);
        }

        mobilDtoList = mobilDtoList.stream().filter(mobilDto -> {
            return mobilDto.getIsDeleted() != null && mobilDto.getIsDeleted() == false;
                })
                        .collect(Collectors.toList());

        responseMobilDto.setMobilDto(mobilDtoList);
        responseMobilDto.setSuccess(true);
        responseMobilDto.setTotalData(mobilDtoList.size());
        responseMobilDto.setTotalPage(mobilList.getTotalPages());

        return responseMobilDto;
    }

    @Override
    public MobilDto deleteById(Integer id) {
        Optional<Mobil> mobilOptional = mobilRepository.findById(id.longValue());
        Mobil mobil = null;

        if (mobilOptional.isPresent()) {
            mobil = mobilOptional.get();
            mobil.setIsDeleted(true);
            Mobil mobilUpdated = mobilRepository.save(mobil);

            MobilDto mobilDtoUpdated = convertMobilToMobilDto(mobilUpdated);

            return mobilDtoUpdated;
        }

        return null;
    }

    @Override
    public MobilDto getById(Integer id) throws JsonProcessingException {
        Optional<Mobil> mobilOptional = mobilRepository.findById(id.longValue());
        Mobil mobil = new Mobil();

        if (mobilOptional.isPresent()) {
            mobil = mobilOptional.get();

            return convertMobilToMobilDto(mobil);
        }
        return null;
    }

    @Override
    public MobilDto uploadImage(Integer id, MultipartFile image) {
        MobilDto mobilDto = new MobilDto();
        try {
            Optional<Mobil> mobilOptional = mobilRepository.findById(id.longValue());
            if (mobilOptional.isPresent()) {
                Mobil mobil = mobilOptional.get();
                MobilDetail mobilDetail = mobil.getMobilDetail();
                mobilDetail.setImage(image.getBytes());
                mobilDetailRepository.save(mobilDetail);

                mobilDto = convertMobilToMobilDto(mobil);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return mobilDto;
    }

    @Override
    public MobilDto createByFile(MultipartFile image, MultipartFile file) {
        if (!file.isEmpty()) {
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(file.getInputStream()));

                Mobil mobil = new Mobil();
                MobilDetail mobilDetail = new MobilDetail();
                String line;
                int lineNumber = 0;
                while ((line = br.readLine()) != null) {
                    if (lineNumber == 0) {
                        mobil.setBrand(line);
                    } else if (lineNumber == 1) {
                        mobilDetail.setColor(line);
                    } else if (lineNumber == 2) {
                        mobilDetail.setName(line);
                    } else if (lineNumber == 3) {
                        mobilDetail.setPrice(Double.parseDouble(line));
                    } else if (lineNumber == 4) {
                        mobilDetail.setSpec(line);
                    }
                    lineNumber++;
                }

                if (!image.isEmpty()) {
                    mobilDetail.setImage(image.getBytes());
                }
                mobil.setMobilDetail(mobilDetail);
                mobil.setIsDeleted(false);

                Mobil mobilSaved = mobilRepository.save(mobil);

                MobilDto mobilDto = convertMobilToMobilDto(mobilSaved);

                return mobilDto;
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return null;
    }

    @Override
    public String createByFiles(MultipartFile[] files) {
        long startTime = System.currentTimeMillis();
        ExecutorService executorService = Executors.newFixedThreadPool(3);

        for (int i=0; i<files.length; i++) {
            try {
                BufferedReader br = new BufferedReader(new InputStreamReader(files[i].getInputStream()));

                Mobil mobil = new Mobil();
                MobilDetail mobilDetail = new MobilDetail();
                String line;
                int lineNumber = 0;
                while ((line = br.readLine()) != null) {
                    if (lineNumber == 0) {
                        mobil.setBrand(line);
                    } else if (lineNumber == 1) {
                        mobilDetail.setColor(line);
                    } else if (lineNumber == 2) {
                        mobilDetail.setName(line);
                    } else if (lineNumber == 3) {
                        mobilDetail.setPrice(Double.parseDouble(line));
                    } else if (lineNumber == 4) {
                        mobilDetail.setSpec(line);
                    }
                    lineNumber++;
                }

                mobil.setMobilDetail(mobilDetail);
                mobil.setIsDeleted(false);

                Runnable workerRunnable = new WorkerRunnable(mobil);
                executorService.execute(workerRunnable);

            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        executorService.shutdown();
        long endTime = System.currentTimeMillis();
        long duration = endTime - startTime;

        return "Duration = " + duration + " mili detik. " + files.length + " files are saved";
    }

    class WorkerRunnable implements Runnable {
        private Mobil mobil;

        public WorkerRunnable(Mobil mobil) {
            this.mobil = mobil;
        }

        @Override
        public void run() {
            try {
//                Mobil mobilSaved = mobilRepository.save(mobil);
//                MobilDto mobilDto = convertMobilToMobilDto(mobilSaved);
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public MobilDto createByForm(MultipartFile image, String brand, String color, String price) {
        System.out.println("brand = " + brand);
        Mobil mobil = new Mobil();
            MobilDetail mobilDetail = new MobilDetail();
            mobilDetail.setPrice(Double.parseDouble(price));
            mobilDetail.setColor(color);
            if (!image.isEmpty()) {
                try {
                    mobilDetail.setImage(image.getBytes());
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        mobil.setMobilDetail(mobilDetail);
        mobil.setIsDeleted(false);
        mobil.setBrand(brand);

        mobilRepository.save(mobil);

        MobilDto mobilDto = convertMobilToMobilDto(mobil);

        return mobilDto;
    }

    private MobilDto convertMobilToMobilDto(Mobil mobilCreated) {
        // create new
        if (mobilCreated.getId() == null) {
            MobilDto mobilDtoCreated = new MobilDto();
            mobilDtoCreated.setId(mobilCreated.getId());
            mobilDtoCreated.setIsDeleted(mobilCreated.getIsDeleted());
            mobilDtoCreated.setBrand(mobilCreated.getBrand());

            MobilDetailDto mobilDetailDtoCreated = new MobilDetailDto();
            mobilDetailDtoCreated.setColor(mobilCreated.getMobilDetail().getColor());
            mobilDetailDtoCreated.setId(mobilCreated.getMobilDetail().getId());
            mobilDetailDtoCreated.setIsNew(mobilCreated.getMobilDetail().getIsNew());
            mobilDetailDtoCreated.setPrice(mobilCreated.getMobilDetail().getPrice());
            mobilDetailDtoCreated.setYear(mobilCreated.getMobilDetail().getYear());
            mobilDetailDtoCreated.setName(mobilCreated.getMobilDetail().getName());
            mobilDetailDtoCreated.setSpec(mobilCreated.getMobilDetail().getSpec());

            mobilDtoCreated.setMobilDetailDto(mobilDetailDtoCreated);
            return mobilDtoCreated;
        }
        // update
        else {
            Optional<Mobil> existingMobilOptional = mobilRepository.findById(mobilCreated.getId());
            Mobil existingMobil = existingMobilOptional.get();

            MobilDto mobilDtoCreated = new MobilDto();
            mobilDtoCreated.setId(existingMobil.getId());
            mobilDtoCreated.setIsDeleted(existingMobil.getIsDeleted());
            mobilDtoCreated.setBrand(existingMobil.getBrand());

            MobilDetailDto mobilDetailDtoUpdated = new MobilDetailDto();
            mobilDetailDtoUpdated.setColor(existingMobil.getMobilDetail().getColor());
            mobilDetailDtoUpdated.setId(existingMobil.getMobilDetail().getId());
            mobilDetailDtoUpdated.setIsNew(existingMobil.getMobilDetail().getIsNew());
            mobilDetailDtoUpdated.setPrice(existingMobil.getMobilDetail().getPrice());
            mobilDetailDtoUpdated.setYear(existingMobil.getMobilDetail().getYear());
            mobilDetailDtoUpdated.setName(existingMobil.getMobilDetail().getName());
            mobilDetailDtoUpdated.setSpec(existingMobil.getMobilDetail().getSpec());

            mobilDtoCreated.setMobilDetailDto(mobilDetailDtoUpdated);
            return mobilDtoCreated;
        }
    }

    private Mobil convertMobilDtoToMobil(MobilDto mobilDto) {
        Mobil mobil = new Mobil();
        mobil.setBrand(mobilDto.getBrand());
        mobil.setIsDeleted(false);

        MobilDetail mobilDetail = new MobilDetail();
        mobilDetail.setIsNew(mobilDto.getMobilDetailDto().getIsNew());
        mobilDetail.setColor(mobilDto.getMobilDetailDto().getColor());
        mobilDetail.setPrice(mobilDto.getMobilDetailDto().getPrice());
        mobilDetail.setYear(mobilDto.getMobilDetailDto().getYear());
        mobilDetail.setName(mobilDto.getMobilDetailDto().getName());
        mobilDetail.setSpec(mobilDto.getMobilDetailDto().getSpec());
        mobil.setMobilDetail(mobilDetail);
        return mobil;
    }
}
