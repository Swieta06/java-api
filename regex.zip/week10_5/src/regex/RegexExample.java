package regex;

import java.util.regex.Pattern;

public class RegexExample {
    public static void main(String[] args) {
        // regex untuk validasi, mencari sebuah string, replace, split berdasarkan sebuah char
        boolean validasi1 = Pattern.matches("\\w+", "!@");      // +: harus muncul minimal 1 x
        boolean validasi2 = Pattern.matches("\\W*", "!#%");     // *: harus muncul minimal 0 x
        boolean validasi3 = Pattern.matches(".a", "%a");        // .: harus ada 1 char
        boolean validasi4 = Pattern.matches("a?", "aa");        // ?: ada 0 atau 1 x
        boolean validasi5 = Pattern.matches("[ab]{5}", "aabbb");   // {5}: ada 5 x
        System.out.println("huruf aabbb = " + validasi5);

        // 1. matches a string contains only a certain set of characters (in this case a-z, A-Z and 0-9)
        System.out.println(Pattern.matches("\\w+", "0aB98Vfr23"));

        // 2. matches a string that has an a followed by zero or more b's
        // a
        // ab
        // abb
        // abbbbbb
        System.out.println(Pattern.matches("ab*", "ab"));

        // 3. matches a string that has one or more 'a' followed by one or more 'b'
        // ab
        // aab
        // aaaaaab
        // abbbb
        System.out.println(Pattern.matches("a+b+", "aaabbb"));

        // 4. matches a string that has one 'a' followed by three 'b'
        System.out.println(Pattern.matches("ab{3}", "abbbb"));

        // 5. matches a string that has one 'a' followed by two to three 'b'
        // abb
        // abbb
        System.out.println("abb : " + Pattern.matches("ab{2,3}", "abb"));
        System.out.println("abbb : " + Pattern.matches("ab{2,3}", "abbb"));
        System.out.println("ab : " + Pattern.matches("ab{2,3}", "ab"));

        // 6. matches sequences of lowercase letters joined with a underscore
        System.out.println(Pattern.matches("[a-z]+_", "abc_"));

        // 7. matches of one upper case letter followed by lower case letters
        // Bkops
        System.out.println("Bkops: " + Pattern.matches("[A-Z][a-z]+", "Bkops"));

        // 8. matches a string that has one 'a' followed by anything, ending in 'b'
        // ab
        // a124niewrnwernob
        System.out.println("ab: " + Pattern.matches("a[a-zA-Z0-9]*b", "ab"));

        // 9. matches a word at the end of string, with optional punctuation (tanda baca)
        // HEllo.
        // iya?
        // Ya!
        // ehmmm,
        System.out.println("Hello. : " + Pattern.matches("\\w+[.?!,]", "Hello."));
        System.out.println("ehmmm: : " + Pattern.matches("\\w+[.?!,]", "ehmmm:"));

        // 10. matches a word containing 'z'
        // z diawal: zabc123
        // z ditengah: a1zbc23
        // z diakhir: abc123z
        System.out.println("abz12 : " + Pattern.matches("z\\w+|\\w+z\\w+|\\w+z", "zab12"));

        // 12. matches a word containing 'z', not at the start or end of the word
        System.out.println("azb : " + Pattern.matches("[a-yA-Y0-9]+z+[a-yA-Y0-9]+", "azb"));

        // 13. matches a string that contains only upper and lowercase letters, numbers, and underscores
        System.out.println("aB0_ : " + Pattern.matches("[a-zA-Z0-9_]+", "aB0_"));
        System.out.println("a_B0! : " + Pattern.matches("[a-zA-Z0-9_]+", "a_B0!"));

        // 14. matches a string will start with a specific number
        // 1abc4tew
        System.out.println("1abc4tew : " + Pattern.matches("[0-9]\\w+", "1abc4tew"));

        // 15. matches a string that ends in a number yang berjumlah kelipatan 3
        // ab111
        // ab111111
        // ab111333555
        System.out.println("12345678 : " + Pattern.matches("([0-9]{3})+", "12345678"));
        System.out.println("123456 : " + Pattern.matches("([0-9]{3})+", "111111111"));

        // 16. matches the numbers (0-9) of length between 1 to 3 in a given string
        // 17. Match numbers containing floating point
        // 18. matches a word contain email: abi2000@gmail.com, budiman1999@gmail.co.id, cecilia@hotmail.com
        // 19. matches a word contain ip address: (boleh terima 1 - 3 huruf, jika 3 huruf maximal 256)
        // 0.0.0.0, 12.256.1.15, 256.256.256.256, 000,00,5,100
        // 20. matches a word that starts with 'a' kelipatan 3 x dan diakhiri huruf 'b' kelipatan 2 x
        // aaabb, aaaaaabbbb
    }
}

