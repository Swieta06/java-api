package synrgy.belajar.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import synrgy.belajar.model.CourseRating;
import synrgy.belajar.model.CourseRatingKey;

@Repository
public interface CourseRatingRepository extends JpaRepository<CourseRating, CourseRatingKey> {
    
}
