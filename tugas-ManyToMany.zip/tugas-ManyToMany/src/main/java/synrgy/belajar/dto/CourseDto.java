package synrgy.belajar.dto;

import java.util.List;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import synrgy.belajar.model.CourseRating;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class CourseDto {
    
    private UUID id;
    private String name;
    private List<CourseRating> students;
    
    public CourseDto(UUID id, String name) {
        this.id = id;
        this.name = name;
    }
    
}
