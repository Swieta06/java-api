package synrgy.belajar.dto;

public class CustomDto<T> {
    
    private Boolean success;
    private T object;


    public CustomDto() {
    }
    public CustomDto(Boolean success, T object) {
        this.success = success;
        this.object = object;
    }


    public Boolean getSuccess() {
        return success;
    }
    public void setSuccess(Boolean success) {
        this.success = success;
    }
    public T getObject() {
        return object;
    }
    public void setObject(T object) {
        this.object = object;
    }

    

}
