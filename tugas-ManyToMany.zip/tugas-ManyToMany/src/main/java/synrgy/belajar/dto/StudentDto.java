package synrgy.belajar.dto;

import java.util.List;
import java.util.UUID;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class StudentDto {
    
    private UUID id;
    private String name;
    private Double gpa;
    private String address;
    private List<CourseRatingDto> courses;

    public StudentDto(UUID id, String name, Double gpa, String address) {
        this.id = id;
        this.name = name;
        this.gpa = gpa;
        this.address = address;
    }
    
}
