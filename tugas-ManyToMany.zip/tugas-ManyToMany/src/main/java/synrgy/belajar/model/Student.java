package synrgy.belajar.model;

import java.util.List;
import java.util.UUID;

import javax.persistence.*;

import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "student")
@SQLDelete(sql = "UPDATE student SET is_deleted = true WHERE id = ?")
@Where(clause = "is_deleted = false")
public class Student {
    
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private UUID id;

    @Column(name = "name")
    private String name;

    @Column(name = "gpa")
    private Double gpa;

    @Column(name = "address")
    private String address;
    
    @Column(name = "role")
    private String role;

    // @OneToMany(mappedBy = "student", cascade = CascadeType.PERSIST, fetch = FetchType.EAGER)
    @OneToMany(mappedBy = "student")
    private List<CourseRating> courses;

    @Column(name = "is_deleted")
    private Boolean isDeleted = false;

    public Student(UUID id, String name, Double gpa, String address) {
        this.id = id;
        this.name = name;
        this.gpa = gpa;
        this.address = address;
    }
    
}
