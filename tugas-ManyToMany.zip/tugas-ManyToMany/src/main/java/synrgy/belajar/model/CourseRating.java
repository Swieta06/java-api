package synrgy.belajar.model;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "course_rating")
public class CourseRating {
    
    @EmbeddedId
    private CourseRatingKey id;

    // @ManyToOne(cascade = CascadeType.PERSIST)
    @ManyToOne
    @MapsId(value = "studentId")
    @JoinColumn(name = "student_id")
    private Student student;

    // @ManyToOne(cascade = CascadeType.PERSIST)
    @ManyToOne
    @MapsId(value = "courseId")
    @JoinColumn(name = "course_id")
    private Course course;

    private Integer rating;
    
}
