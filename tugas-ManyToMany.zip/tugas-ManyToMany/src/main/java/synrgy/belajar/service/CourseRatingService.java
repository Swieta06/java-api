package synrgy.belajar.service;

import java.util.UUID;

import org.springframework.http.ResponseEntity;

import synrgy.belajar.dto.CourseRatingDto;

public interface CourseRatingService {
    
    ResponseEntity<String> studentSetCourseRating(UUID studentId, CourseRatingDto courseRatingDto);

}
