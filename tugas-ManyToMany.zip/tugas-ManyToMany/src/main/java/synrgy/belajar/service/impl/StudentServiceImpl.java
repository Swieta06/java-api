package synrgy.belajar.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import synrgy.belajar.dto.CourseDto;
import synrgy.belajar.dto.CourseRatingDto;
import synrgy.belajar.dto.StudentDto;
import synrgy.belajar.model.CourseRating;
import synrgy.belajar.model.Student;
import synrgy.belajar.repository.StudentRepository;
import synrgy.belajar.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService {
    
    @Autowired
    private StudentRepository studentRepository;

    public List<StudentDto> getStudents() {
        List<Student> students = this.studentRepository.findAll();
        List<StudentDto> studentDtos = new ArrayList<>();
        
        for (Student student: students) {
            List<CourseRatingDto> courseDtos = new ArrayList<>();

            for (CourseRating rating: student.getCourses()) {
                CourseRatingDto courseRatingDto = new CourseRatingDto(
                    rating.getId().getCourseId(),
                    rating.getCourse().getName(),
                    rating.getRating()
                );

                courseDtos.add(courseRatingDto);
            }

            StudentDto studentDto = new StudentDto(
                student.getId(),
                student.getName(),
                student.getGpa(),
                student.getAddress(),
                courseDtos
            );

            studentDtos.add(studentDto);
        }

        return studentDtos;
    }

    public StudentDto getStudentById(UUID id) {
        return this.studentRepository.findById(id).map(student -> {
            List<CourseRatingDto> courseDtos = new ArrayList<>();

            for (CourseRating rating: student.getCourses()) {
                CourseRatingDto courseRatingDto = new CourseRatingDto(
                    rating.getId().getCourseId(),
                    rating.getCourse().getName(),
                    rating.getRating()
                );

                courseDtos.add(courseRatingDto);
            }

            return new StudentDto(
                student.getId(),
                student.getName(),
                student.getGpa(),
                student.getAddress(),
                courseDtos
            );
        }).orElse(null);
    }

    public Student insertStudent(StudentDto studentDto) {
        Student savedStudent = this.studentRepository.save(
            new Student(
                null,
                studentDto.getName(),
                studentDto.getGpa(),
                studentDto.getAddress()
            )
        );
        return savedStudent;
    }
    
    public void updateStudent(UUID id, StudentDto studentDto) {
        this.studentRepository.save(
            new Student(
                id,
                studentDto.getName(),
                studentDto.getGpa(),
                studentDto.getAddress()
            )
        );
    }

    public void deleteStudent(UUID id) {
        this.studentRepository.deleteById(id);
    }
    
}
