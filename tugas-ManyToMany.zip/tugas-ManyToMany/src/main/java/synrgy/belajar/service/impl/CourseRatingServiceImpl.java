package synrgy.belajar.service.impl;

import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import synrgy.belajar.dto.CourseRatingDto;
import synrgy.belajar.model.Course;
import synrgy.belajar.model.CourseRating;
import synrgy.belajar.model.CourseRatingKey;
import synrgy.belajar.model.Student;
import synrgy.belajar.repository.CourseRatingRepository;
import synrgy.belajar.repository.CourseRepository;
import synrgy.belajar.repository.StudentRepository;
import synrgy.belajar.service.CourseRatingService;

@Service
@Transactional
public class CourseRatingServiceImpl implements CourseRatingService {

    @Autowired
    private StudentRepository studentRepository;

    @Autowired
    private CourseRepository courseRepository;

    @Autowired
    private CourseRatingRepository courseRatingRepository;

    public ResponseEntity<String> studentSetCourseRating(UUID studentId, CourseRatingDto courseRatingDto) {
        UUID courseId = courseRatingDto.getCourseId();

        Optional<Student> studentOptional = this.studentRepository.findById(studentId);
        if (studentOptional.isPresent()) {
            Optional<Course> courseOptional = this.courseRepository.findById(courseId);
            if (courseOptional.isPresent()) {
                this.courseRatingRepository.save(
                    new CourseRating(
                        new CourseRatingKey(studentId, courseId),
                        studentOptional.get(),
                        courseOptional.get(),
                        courseRatingDto.getRating()
                    )
                );
                return new ResponseEntity<>(HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Course tidak ditemukan!", HttpStatus.NOT_FOUND);
            }
        } else {
            return new ResponseEntity<>("Student tidak ditemukan", HttpStatus.NOT_FOUND);
        }
    }

}
