package synrgy.belajar.service;

import java.util.List;
import java.util.UUID;

import synrgy.belajar.dto.StudentDto;
import synrgy.belajar.model.Student;

public interface StudentService {
    
    List<StudentDto> getStudents();
    StudentDto getStudentById(UUID id);
    Student insertStudent(StudentDto studentDto);
    void updateStudent(UUID id, StudentDto studentDto);
    void deleteStudent(UUID id);

}
