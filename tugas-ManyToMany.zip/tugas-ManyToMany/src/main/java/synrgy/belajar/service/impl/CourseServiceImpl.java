package synrgy.belajar.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import synrgy.belajar.dto.CourseDto;
import synrgy.belajar.model.Course;
import synrgy.belajar.repository.CourseRepository;
import synrgy.belajar.service.CourseService;

@Service
public class CourseServiceImpl implements CourseService {
    
    @Autowired
    private CourseRepository courseRepository;

    public List<CourseDto> getCourses() {
        List<Course> courses = this.courseRepository.findAll();
        List<CourseDto> courseDtos = new ArrayList<>();

        for (Course course: courses) {
            courseDtos.add(
                new CourseDto(
                    course.getId(),
                    course.getName()
                )
            );
        }

        return courseDtos;
    }

    public CourseDto getCourseById(UUID id) {
        return this.courseRepository.findById(id).map(course -> {
            return new CourseDto(
                course.getId(),
                course.getName()
            );
        }).orElse(null);
    }
    
    public void insertCourse(CourseDto courseDto) {
        this.courseRepository.save(
            new Course(
                null,
                courseDto.getName()
            )
        );
    }
    
    public void updateCourse(UUID id, CourseDto courseDto) {
        this.courseRepository.save(
            new Course(
                id,
                courseDto.getName()
            )
        );
    }

    public void deleteCourse(UUID id) {
        this.courseRepository.deleteById(id);
    }






}
