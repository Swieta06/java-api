package synrgy.belajar.service;

import java.util.List;
import java.util.UUID;

import synrgy.belajar.dto.CourseDto;

public interface CourseService {
    
    List<CourseDto> getCourses();
    CourseDto getCourseById(UUID id);
    void insertCourse(CourseDto courseDto);
    void updateCourse(UUID id, CourseDto courseDto);
    void deleteCourse(UUID id);

}
