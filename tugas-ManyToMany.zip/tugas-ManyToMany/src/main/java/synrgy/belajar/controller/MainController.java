package synrgy.belajar.controller;

import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import synrgy.belajar.dto.CourseDto;
import synrgy.belajar.dto.CourseRatingDto;
import synrgy.belajar.dto.StudentDto;
import synrgy.belajar.service.CourseRatingService;
import synrgy.belajar.service.CourseService;
import synrgy.belajar.service.StudentService;

@RestController
public class MainController {
    
    @Autowired
    private StudentService studentService;

    @Autowired
    private CourseService courseService;

    @Autowired
    private CourseRatingService courseRatingService;

    @GetMapping("/students")
    public List<StudentDto> getStudents() {
        return this.studentService.getStudents();
    }

    @GetMapping("/students/{id}")
    public StudentDto getStudentById(@PathVariable UUID id) {
        return this.studentService.getStudentById(id);
    }

    @PostMapping("/students")
    public ResponseEntity<String> insertStudent(@RequestBody StudentDto studentDto) {
        try { 
            this.studentService.insertStudent(studentDto);
            return new ResponseEntity<>(HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.CONFLICT);
        }
    }

    @PutMapping("/students/{id}")
    public void updateStudent(@PathVariable UUID id, @RequestBody StudentDto studentDto) {
        this.studentService.updateStudent(id, studentDto);
    }

    @DeleteMapping("/students/{id}")
    public void deleteStudent(@PathVariable UUID id) {
        this.studentService.deleteStudent(id);
    }

    @GetMapping("/courses")
    public List<CourseDto> getCourses() {
        return this.courseService.getCourses();
    }

    @GetMapping("/courses/{id}")
    public CourseDto getCourseById(@PathVariable UUID id) {
        return this.courseService.getCourseById(id);
    }

    @PostMapping("/courses")
    public void insertCourse(@RequestBody CourseDto courseDto) {
        this.courseService.insertCourse(courseDto);
    }

    @PutMapping("/courses/{id}")
    public void updateCourse(@PathVariable UUID id, @RequestBody CourseDto courseDto) {
        this.courseService.updateCourse(id, courseDto);
    }

    @DeleteMapping("/courses/{id}")
    public void deleteCourse(@PathVariable UUID id) {
        this.courseService.deleteCourse(id);
    }
    
    @PostMapping("/rating/{student_id}")
    public ResponseEntity<String> courseRating(
        @PathVariable UUID student_id,
        @RequestBody CourseRatingDto courseRatingDto
    ) {
        return courseRatingService.studentSetCourseRating(student_id, courseRatingDto);
    }

}
