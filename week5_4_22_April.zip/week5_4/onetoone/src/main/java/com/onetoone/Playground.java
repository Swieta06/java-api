package com.onetoone;

public class Playground {
    public static void main(String[] args) throws InterruptedException {
        // java eksekusi secara synchronous
        System.out.println("Hello Jensen1");

        Thread.sleep(3000);
        System.out.println("Hello Jensen2");

        Thread.sleep(5000);
        System.out.println("Hello Jensen3");
    }
}
