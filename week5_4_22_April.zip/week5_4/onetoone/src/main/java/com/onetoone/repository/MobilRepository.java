package com.onetoone.repository;

import com.onetoone.entity.Mobil;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MobilRepository extends JpaRepository<Mobil, Long> {
}
