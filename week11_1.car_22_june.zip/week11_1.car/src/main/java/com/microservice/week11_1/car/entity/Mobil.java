package com.microservice.week11_1.car.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

@Entity
@Table(name = "microservice_mobil")
@NoArgsConstructor
@Getter
@Setter
@ToString
public class Mobil {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "brand")
    private String brand;

    @Column(name = "is_deleted") // snake case
    private Boolean isDeleted; // camel case

    @Column(name = "mobil_detail_id")
    private Long mobilDetailId;
}
