package com.microservice.week11_1.car.controller;

import com.microservice.week11_1.car.dto.MobilReqDto;
import com.microservice.week11_1.car.dto.MobilRespDto;
import com.microservice.week11_1.car.entity.Mobil;
import com.microservice.week11_1.car.service.MobilService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/mobil")
public class MobilController {
    @Autowired
    private MobilService mobilService;

    @PostMapping("/create")
    public void create(@RequestBody MobilReqDto mobilDto) {
        this.mobilService.create(mobilDto);
    }

    @GetMapping("/getAll")
    public List<Mobil> getAll() {
        return this.mobilService.findAll();
    }

    @GetMapping("/getById/{id}")
    public MobilRespDto getById(@PathVariable Long id) {
        return this.mobilService.getById(id);
    }
}
