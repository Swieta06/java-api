package com.microservice.week11_1.car.repository;

import com.microservice.week11_1.car.entity.Mobil;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MobilRepository extends JpaRepository<Mobil, Long> {
}
