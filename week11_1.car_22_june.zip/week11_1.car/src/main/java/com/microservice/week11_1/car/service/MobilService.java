package com.microservice.week11_1.car.service;

import com.microservice.week11_1.car.dto.MobilReqDto;
import com.microservice.week11_1.car.dto.MobilRespDto;
import com.microservice.week11_1.car.entity.Mobil;

import java.util.List;

public interface MobilService {
    public void create(MobilReqDto mobilDto);

    public List<Mobil> findAll();

    public MobilRespDto getById(Long id);
}
