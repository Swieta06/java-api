package com.microservice.week11_1.car.service;

import com.microservice.week11_1.car.dto.MobilDetailReqDto;
import com.microservice.week11_1.car.dto.MobilReqDto;
import com.microservice.week11_1.car.dto.MobilRespDto;
import com.microservice.week11_1.car.entity.Mobil;
import com.microservice.week11_1.car.repository.MobilRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

@Service
public class MobilServiceImpl implements MobilService {

    @Autowired
    private MobilRepository mobilRepository;

    @Autowired
    private WebClient webClient;

    @Override
    public void create(MobilReqDto mobilDto) {
        Mobil mobil = new Mobil();
        mobil.setBrand(mobilDto.getBrand());
        mobil.setIsDeleted(false);
        mobil.setMobilDetailId(mobil.getMobilDetailId());

        this.mobilRepository.save(mobil);
    }

    @Override
    public List<Mobil> findAll() {
        return this.mobilRepository.findAll();
    }

    @Override
    public MobilRespDto getById(Long id) {
        Optional<Mobil> mobilOptional = this.mobilRepository.findById(id);

        if (mobilOptional.isPresent()) {
            Mobil mobil = mobilOptional.get();

            MobilRespDto mobilDto = new MobilRespDto();
            mobilDto.setBrand(mobil.getBrand());
            mobilDto.setId(mobil.getId());
            mobilDto.setIsDeleted(mobil.getIsDeleted());
            mobilDto.setMobilDetailDto(getMobilDetail(mobil));

            return mobilDto;
        }

        return null;
    }

    private MobilDetailReqDto getMobilDetail(Mobil mobil) {
        Mono<MobilDetailReqDto> mobilDetailDtoMono = webClient.get().uri("/getById/" + mobil.getMobilDetailId())
                .retrieve().bodyToMono(MobilDetailReqDto.class);

        MobilDetailReqDto mobilDetailReqDto = mobilDetailDtoMono.block();

        return mobilDetailReqDto;
    }
}
