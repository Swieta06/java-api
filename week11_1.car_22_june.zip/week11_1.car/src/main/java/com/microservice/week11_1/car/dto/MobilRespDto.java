package com.microservice.week11_1.car.dto;

import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@ToString
public class MobilRespDto {
    private Long id;

    private String brand;

    private Boolean isDeleted;

    private MobilDetailReqDto mobilDetailDto;
}
