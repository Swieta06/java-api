package com.microservice.week11_1.car.service;

import com.microservice.week11_1.car.dto.MobilDetailReqDto;
import com.microservice.week11_1.car.dto.MobilReqDto;
import com.microservice.week11_1.car.dto.MobilRespDto;
import com.microservice.week11_1.car.entity.Mobil;
import com.microservice.week11_1.car.openFeigns.MobilDetailOpenFeigns;
import com.microservice.week11_1.car.repository.MobilRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;

@Service
public class MobilServiceImpl implements MobilService {

    @Autowired
    private MobilRepository mobilRepository;

    @Autowired
    private WebClient webClient;

    @Autowired
    private MobilDetailOpenFeigns mobilDetailOpenFeigns;

    @Override
    public MobilRespDto create(MobilReqDto mobilDto) {
        Mobil mobil = new Mobil();
        mobil.setBrand(mobilDto.getBrand());
        mobil.setIsDeleted(false);
        mobil.setMobilDetailId(mobilDto.getMobilDetailId());

        mobil = this.mobilRepository.save(mobil);

        MobilRespDto mobilRespDto = new MobilRespDto(mobil);
//        mobilRespDto.setMobilDetailDto(getMobilDetail(mobil));
        mobilRespDto.setMobilDetailDto(mobilDetailOpenFeigns.getById(mobil.getId()));

        return mobilRespDto;
    }

    @Override
    public List<Mobil> findAll() {
        return this.mobilRepository.findAll();
    }

    @Override
    public MobilRespDto getById(Long id) {
        Optional<Mobil> mobilOptional = this.mobilRepository.findById(id);

        if (mobilOptional.isPresent()) {
            Mobil mobil = mobilOptional.get();

            MobilRespDto mobilDto = new MobilRespDto();
            mobilDto.setBrand(mobil.getBrand());
            mobilDto.setId(mobil.getId());
            mobilDto.setIsDeleted(mobil.getIsDeleted());
//            mobilDto.setMobilDetailDto(getMobilDetail(mobil));
            mobilDto.setMobilDetailDto(mobilDetailOpenFeigns.getById(mobil.getId()));

            return mobilDto;
        }

        return null;
    }

    private MobilDetailReqDto getMobilDetail(Mobil mobil) {
        // apa bedanya webClient dengan restTemplate
        // webClient: asynchronous (non-blocking)
        // restTemplate: synchronous (blocking)
        Mono<MobilDetailReqDto> mobilDetailDtoMono = webClient.get().uri("/getById/" + mobil.getMobilDetailId())
                .retrieve().bodyToMono(MobilDetailReqDto.class);

        MobilDetailReqDto mobilDetailReqDto = mobilDetailDtoMono.block();

        return mobilDetailReqDto;
    }
}
