package com.microservice.week11_1.car.openFeigns;

import com.microservice.week11_1.car.dto.MobilDetailReqDto;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(value = "car-detail-service", path = "/api/mobilDetail")
public interface MobilDetailOpenFeigns {

    @GetMapping("/getById/{id}")
    public MobilDetailReqDto getById(@PathVariable Long id);
}
