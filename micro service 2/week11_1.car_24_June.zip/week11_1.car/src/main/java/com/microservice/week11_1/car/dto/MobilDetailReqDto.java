package com.microservice.week11_1.car.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class MobilDetailReqDto {
    private Long id;
    private Double price;
    private String name;
}
