package com.microservice.week11_1.car.dto;

import com.microservice.week11_1.car.entity.Mobil;
import lombok.*;

@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@ToString
public class MobilRespDto {
    private Long id;

    private String brand;

    private Boolean isDeleted;

    private MobilDetailReqDto mobilDetailDto;

    public MobilRespDto(Mobil mobil) {
        this.id = mobil.getId();
        this.brand = mobil.getBrand();
        this.isDeleted = mobil.getIsDeleted();
    }
}
