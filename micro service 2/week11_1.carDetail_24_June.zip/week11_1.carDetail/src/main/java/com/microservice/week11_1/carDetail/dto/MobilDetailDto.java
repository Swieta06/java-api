package com.microservice.week11_1.carDetail.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class MobilDetailDto {
    private Long id;
    private Double price;
    private String name;
}
