package tugasbe.tugas_onetomany.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class ChapterDto {
    
    private Long id;
    private String name;
    private String content;
    @JsonIgnore
    private Long book_id;
    @JsonIgnore
    private boolean isDeleted;
    @JsonIgnore
    private BookDto bookDto;



    public ChapterDto() {
    }
    public ChapterDto(Long id, String name, String content, Long book_id, boolean isDeleted, BookDto bookDto) {
        this.id = id;
        this.name = name;
        this.content = content;
        this.book_id = book_id;
        this.isDeleted = isDeleted;
        this.bookDto = bookDto;
    }
    
    public ChapterDto(Long id, String name, String content) {
        this.id = id;
        this.name = name;
        this.content = content;
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getContent() {
        return content;
    }
    public void setContent(String content) {
        this.content = content;
    }
    public Long getBook_id() {
        return book_id;
    }
    public void setBook_id(Long book_id) {
        this.book_id = book_id;
    }
    public boolean getIsDeleted() {
        return isDeleted;
    }
    public void setIsDeleted(boolean isDeleted) {
        this.isDeleted = isDeleted;
    }
    public BookDto getBookDto() {
        return bookDto;
    }
    public void setBookDto(BookDto bookDto) {
        this.bookDto = bookDto;
    }

    @Override
    public String toString() {
        return "ChapterDto [bookDto=" + bookDto + ", book_id=" + book_id + ", content=" + content + ", id=" + id
                + ", isDeleted=" + isDeleted + ", name=" + name + "]";
    }

}
