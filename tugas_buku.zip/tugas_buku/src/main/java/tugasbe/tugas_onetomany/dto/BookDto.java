package tugasbe.tugas_onetomany.dto;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

public class BookDto {
    
    private Long id;
    private String title;
    private String year;
    private String author;
    @JsonIgnore
    private boolean isDeleted;
    private List<ChapterDto> chapterDtos;
    
    
    public BookDto() {
    }
    public BookDto(Long id, String title, String year, String author, boolean isDeleted, List<ChapterDto> chapterDtos) {
        this.id = id;
        this.title = title;
        this.year = year;
        this.author = author;
        this.isDeleted = isDeleted;
        this.chapterDtos = chapterDtos;
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getYear() {
        return year;
    }
    public void setYear(String year) {
        this.year = year;
    }
    public boolean getIsDeleted() {
        return isDeleted;
    }
    public void setIsDeleted(boolean isDeleted) {
        this.isDeleted = isDeleted;
    }
    public List<ChapterDto> getChapterDtos() {
        return chapterDtos;
    }
    public void setChapterDtos(List<ChapterDto> chapterDtos) {
        this.chapterDtos = chapterDtos;
    }
    public String getAuthor() {
        return author;
    }
    public void setAuthor(String author) {
        this.author = author;
    }
    @Override
    public String toString() {
        return "BookDto [author=" + author + ", chapterDtos=" + chapterDtos + ", id=" + id + ", isDeleted=" + isDeleted
                + ", title=" + title + ", year=" + year + "]";
    }

    

}
