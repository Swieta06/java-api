package tugasbe.tugas_onetomany.dto;

import tugasbe.tugas_onetomany.model.Chapter;

public class CustomDtoDua {
    private Long id;
    private String title;
    private String author;
    private Chapter chapter;

    
    public CustomDtoDua() {
    }
    public CustomDtoDua(Long id, String title, String author, Chapter chapter) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.chapter = chapter;
    }
    public Long getId() {
        return id;
    }
    public void setId(Long id) {
        this.id = id;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getAuthor() {
        return author;
    }
    public void setAuthor(String author) {
        this.author = author;
    }
    public Chapter getChapter() {
        return chapter;
    }
    public void setChapter(Chapter chapter) {
        this.chapter = chapter;
    }

    
    
    
}
