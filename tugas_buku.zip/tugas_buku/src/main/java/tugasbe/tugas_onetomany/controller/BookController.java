package tugasbe.tugas_onetomany.controller;

import java.util.List;

import javax.xml.ws.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import tugasbe.tugas_onetomany.dto.BookDto;
import tugasbe.tugas_onetomany.dto.CustomDto;
import tugasbe.tugas_onetomany.dto.CustomDtoDua;
import tugasbe.tugas_onetomany.model.Book;
import tugasbe.tugas_onetomany.model.Chapter;
import tugasbe.tugas_onetomany.repository.BookRepository;
import tugasbe.tugas_onetomany.repository.ChapterRepository;
import tugasbe.tugas_onetomany.service.BookService;

@RestController
@RequestMapping("/books")
public class BookController {
    
    @Autowired
    private BookService bookService;

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private ChapterRepository chapterRepository;


    @GetMapping("/book-where-chapter")
    public ResponseEntity<List<CustomDto>> waduhhhh(@RequestParam String nama) {
        // return this.bookRepository.getBookWhereChapterNameX(nama);
        return new ResponseEntity<>(
            bookRepository.getBookWhereChapterName(nama),
            HttpStatus.ALREADY_REPORTED
        );
    }

    // @GetMapping("/book-join-chapter2")
    // public ResponseEntity<List<CustomDtoDua>> mantapdah() {
    //     return new ResponseEntity<>(
    //         bookRepository.getBookAndChapterDua(),
    //         HttpStatus.ALREADY_REPORTED
    //     );
    // }
    
    @GetMapping("/book-join-chapter")
    public List<CustomDto> waduhhhhx() {
        return this.bookRepository.getBookAndChapter();
    }

    @GetMapping("/eager-books")
    public List<Book> eagerBook() {

        return bookRepository.findAll();
    }


    @GetMapping("/{id}")
    public ResponseEntity<BookDto> getOneBook(@PathVariable Long id) {
        return new ResponseEntity<BookDto>(this.bookService.getOneBook(id), HttpStatus.OK);
    }

    @PostMapping
    public void insertBook(@RequestBody BookDto bookDto) {
        this.bookService.insertBook(bookDto);
    }

    @PutMapping("/{id}")
    public void updateBook(@PathVariable Long id, @RequestBody BookDto bookDto) {
        this.bookService.updateBook(id, bookDto);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteBook(@PathVariable Long id) {
        try {
            this.bookRepository.deleteById(id);
            return new ResponseEntity<>("", HttpStatus.OK);
        } catch(Exception e) {
            return new ResponseEntity<>("tidak ditemukan", HttpStatus.NOT_FOUND);
        }
    }


}
