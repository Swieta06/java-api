package tugasbe.tugas_onetomany.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import tugasbe.tugas_onetomany.repository.ChapterRepository;

@RestController
@RequestMapping("/chapters")
public class ChapterController {
    
    @Autowired
    private ChapterRepository chapterRepository;

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteChapter(@PathVariable Long id) {
        try {
            this.chapterRepository.deleteById(id);
            return new ResponseEntity<>("", HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>("", HttpStatus.NOT_FOUND);
        }
    }

}
