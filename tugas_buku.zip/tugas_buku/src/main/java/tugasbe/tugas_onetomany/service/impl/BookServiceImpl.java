package tugasbe.tugas_onetomany.service.impl;

import java.security.cert.PKIXRevocationChecker.Option;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import tugasbe.tugas_onetomany.dto.BookDto;
import tugasbe.tugas_onetomany.dto.ChapterDto;
import tugasbe.tugas_onetomany.dto.CustomDtoDua;
import tugasbe.tugas_onetomany.model.Book;
import tugasbe.tugas_onetomany.model.Chapter;
import tugasbe.tugas_onetomany.repository.BookRepository;
import tugasbe.tugas_onetomany.repository.ChapterRepository;
import tugasbe.tugas_onetomany.service.BookService;

@Service
public class BookServiceImpl implements BookService {

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private ChapterRepository chapterRepository;


    public BookDto getOneBook(Long id) {
        Optional<Book> bookOptional = this.bookRepository.findById(id);
        return bookOptional.map(book -> {
            List<ChapterDto> chapterDtoList = getChapterDtoList(book);
            return BookToBookDto(book, chapterDtoList);
        }).orElse(null);
    }

    public void insertBook(BookDto bookDto) {
        List<ChapterDto> chapterDtos = bookDto.getChapterDtos();

        Book book = new Book(
            bookDto.getTitle(),
            bookDto.getYear(),
            bookDto.getAuthor()
        );

        this.bookRepository.save(book);
        
        for (ChapterDto chapterDto: chapterDtos) {
            Chapter chapter = new Chapter(
                chapterDto.getName(),
                chapterDto.getContent(),
                book
            );
            this.chapterRepository.save(chapter);
        }
    }

    public void updateBook(Long id, BookDto bookDto) {
        Optional<Book> bookOptional = this.bookRepository.findById(id);

        bookOptional.map(book -> {
            this.bookRepository.save(new Book(
                id,
                bookDto.getTitle(),
                bookDto.getAuthor(),
                bookDto.getYear(),
                false
            ));
            return null;
        }).orElse(null);
    }

    // public List<BookDto> getBookWhereChapterName(String name) {
    //     List<Book> books = this.bookRepository.getBookWhereChapterName(name);
    //     List<ChapterDto> chapterDtoList = new ArrayList<>();
    //     List<BookDto> bookDtos = new ArrayList<>();

    //     for (Book book: books) {
    //         Chapter tempChapter = book.getChapter().get(0);
            
    //         ChapterDto chapterDto = new ChapterDto(
    //             tempChapter.getId(),
    //             tempChapter.getName(),
    //             tempChapter.getContent(),
    //             tempChapter.getIsDeleted()
    //         );

    //         chapterDtoList.add(chapterDto);
            
    //         BookDto bookDto = new BookDto(
    //             book.getId(),
    //             book.getTitle(),
    //             book.getYear(),
    //             book.getAuthor(),
    //             book.getIsDeleted(),
    //             chapterDtoList
    //         );
            
    //         bookDtos.add(bookDto);
    //         System.out.println("\n\n" + bookDto + "\n\n");
    //     }
        
    //     return bookDtos;
    // }
    

    public List<CustomDtoDua> getBookWhereChapterName(String name) {

        // return this.bookRepository.getBookWhereChapterName(name);
        return null;

    }
    
    public List<ChapterDto> getChapterDtoList(Book book) {
        List<Chapter> chapters = this.chapterRepository.findAll();
        List<ChapterDto> chapterDtoList = new ArrayList<>();
            
        // for (Chapter chapter: chapters) {
        //     if (chapter.getBook().getId().equals(book.getId())) {
        //         ChapterDto chapterDto = new ChapterDto(
        //             chapter.getId(),
        //             chapter.getName(),
        //             chapter.getContent(),
        //             chapter.getIsDeleted()
        //         );
        //         chapterDtoList.add(chapterDto);
        //     }
        // }
        return chapterDtoList;
    }

    public BookDto BookToBookDto(Book book, List<ChapterDto> chapterDtoList) {
        return new BookDto(
            book.getId(),
            book.getTitle(),
            book.getYear(),
            book.getAuthor(),
            book.getIsDeleted(),
            chapterDtoList
        );
    }

}
