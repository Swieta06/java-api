package tugasbe.tugas_onetomany.service;

import java.util.List;

import tugasbe.tugas_onetomany.dto.BookDto;
import tugasbe.tugas_onetomany.dto.CustomDtoDua;
import tugasbe.tugas_onetomany.model.Book;
import tugasbe.tugas_onetomany.model.Chapter;

public interface BookService {
    
    BookDto getOneBook(Long id); 
    void insertBook(BookDto bookDto);
    void updateBook(Long id, BookDto bookDto);
    // List<CustomDto> getBookWhereChapterName(String name);

}
