package tugasbe.tugas_onetomany.service;

public interface ChapterService {
    
}
