package tugasbe.tugas_onetomany.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import tugasbe.tugas_onetomany.dto.CustomDto;
import tugasbe.tugas_onetomany.dto.CustomDtoDua;
import tugasbe.tugas_onetomany.model.Book;

@Repository
public interface BookRepository extends JpaRepository<Book, Long> {

    
    @Query(value = 
    "SELECT new tugasbe.tugas_onetomany.dto.CustomDto(b.id, b.title, b.author, b.year, c.name, c.content) " +
    "FROM Book b " +
    "LEFT JOIN Chapter c " +
    "ON b.id = c.book")
    List<CustomDto> getBookAndChapter();
    
    @Query(value = 
    "SELECT new tugasbe.tugas_onetomany.dto.CustomDto(b.id, b.title, b.author, b.year, c.name, c.content) " +
    "FROM Book b " +
    "JOIN Chapter c " +
    "ON b.id = c.book " +
    "WHERE c.name = ?1 AND c.isDeleted = false")
    List<CustomDto> getBookWhereChapterName(String name);

}
