package tugasbe.tugas_onetomany.zcoretan;

public class App {
    
    public static void main(String[] args) {

        Util mantap = new Util();
        
        System.out.println(Util.print("banget"));
        System.out.println(Util.Util2.printDalem());

        mantap.lakukanlah(100, 200);

        System.out.println(Util.Util2.printDalem());
    }

}
