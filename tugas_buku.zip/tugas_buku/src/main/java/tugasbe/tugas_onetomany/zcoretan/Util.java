package tugasbe.tugas_onetomany.zcoretan;

public class Util {
    
    public static String print(String x) {
        return "anjay " + x;
    }

    public void lakukanlah(int a, int b) {
        System.out.println(a + b);
    }

    public static class Util2 {

        public static String printDalem() {
            lakukanLagi();
            return "daleman";
        }

        public static void lakukanLagi() {
            System.out.println("ASTAGAAA");
        }

    }

}
