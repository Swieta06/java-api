package com.jesper.jesper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JesperApplication {

	public static void main(String[] args) {
		SpringApplication.run(JesperApplication.class, args);
	}

}
