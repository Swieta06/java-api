package com.microservice.week11_1.carDetail.repository;

import com.microservice.week11_1.carDetail.entity.MobilDetail;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MobilDetailRepository extends JpaRepository<MobilDetail, Long> {
}
