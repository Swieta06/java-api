package com.microservice.week11_1.carDetail.entity;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

import javax.persistence.*;

@Entity
@Table(name = "microservice_mobil_detail")
@NoArgsConstructor
@Getter
@Setter
@ToString
public class MobilDetail {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "price")
    private Double price;

    @Column(name = "name")
    private String name;
}
