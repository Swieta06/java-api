package com.microservice.week11_1.carDetail.controller;

import com.microservice.week11_1.carDetail.dto.MobilDetailDto;
import com.microservice.week11_1.carDetail.entity.MobilDetail;
import com.microservice.week11_1.carDetail.service.MobilDetailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/mobilDetail")
public class MobilDetailController {

    @Autowired
    private MobilDetailService mobilDetailService;

    @GetMapping("/getAll")
    public List<MobilDetail> getAll() {
        return this.mobilDetailService.findAll();
    }

    @PostMapping("/create")
    public void create(@RequestBody MobilDetailDto mobilDetailDto) {
        this.mobilDetailService.create(mobilDetailDto);
    }

    @GetMapping("/getById/{id}")
    public MobilDetail getById(@PathVariable Long id) {
        return this.mobilDetailService.getById(id);
    }
}
