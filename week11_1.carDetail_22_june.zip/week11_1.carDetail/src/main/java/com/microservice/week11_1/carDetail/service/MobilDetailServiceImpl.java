package com.microservice.week11_1.carDetail.service;

import com.microservice.week11_1.carDetail.dto.MobilDetailDto;
import com.microservice.week11_1.carDetail.entity.MobilDetail;
import com.microservice.week11_1.carDetail.repository.MobilDetailRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MobilDetailServiceImpl implements MobilDetailService {
    @Autowired
    private MobilDetailRepository mobilDetailRepository;

    @Override
    public List<MobilDetail> findAll() {
        return mobilDetailRepository.findAll();
    }

    @Override
    public void create(MobilDetailDto mobilDetailDto) {
        MobilDetail mobilDetail = new MobilDetail();
        mobilDetail.setName(mobilDetailDto.getName());
        mobilDetail.setPrice(mobilDetailDto.getPrice());

        mobilDetailRepository.save(mobilDetail);
    }

    @Override
    public MobilDetail getById(Long id) {
        Optional<MobilDetail> mobilDetailOptional = this.mobilDetailRepository.findById(id);

        if (mobilDetailOptional.isPresent()) {
            return mobilDetailOptional.get();
        }

        return null;
    }
}
