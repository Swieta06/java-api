package com.microservice.week11_1.carDetail.service;

import com.microservice.week11_1.carDetail.dto.MobilDetailDto;
import com.microservice.week11_1.carDetail.entity.MobilDetail;

import java.util.List;

public interface MobilDetailService {
    public List<MobilDetail> findAll();

    public void create(MobilDetailDto mobilDetailDto);

    public MobilDetail getById(Long id);
}
