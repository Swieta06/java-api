package com.petsQu.Lsp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LspApplication {

	public static void main(String[] args) {
		SpringApplication.run(LspApplication.class, args);
	}

}
